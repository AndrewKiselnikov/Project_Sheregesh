<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'a0367416_app_wordpress_0');

/** MySQL database username */
define('DB_USER', 'a0367416_app_wordpress_0');

/** MySQL database password */
define('DB_PASSWORD', 'h7yT8rNB0E');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'x(BKy(w1@Z^p225!j9%AQ31CL8o&TA^^LQrP6Bbz%5VJax5CR1&izbcwWe6bD4ek');
define('SECURE_AUTH_KEY',  '(WlM2qOYGdALe(cWEKWO4(f!aLshC*QF7ggPabKMv@HJ00L0*B5lcgU)izpRN(06');
define('LOGGED_IN_KEY',    'R5j%^Zl5ChLW5WeKVzTsGnxy3AI3K4D7k!peR*#mgbGEn^oTnLcdrhb1nF0@rSxW');
define('NONCE_KEY',        'o6G&LrF*WFZ!qS0QFEds@VgyHO8S)#zfbdUvMDA0yl@u^tANT%LLXP)3pRmCT!gN');
define('AUTH_SALT',        '&u(0hrtc0fOs%ekSGKsl!K&4R75qkmkCRpy8amLs#srk3gxmu6P*6(%lRQ(KYp5z');
define('SECURE_AUTH_SALT', '8ijttr3CNJ87*@BTLmnB8n*Ev@RjB*JhVjWiJfZ%U7oF^x%7y!4pk(6To1%2e1J4');
define('LOGGED_IN_SALT',   'OCFa!Gp4Q7y8AB7@QIxnoVSFSeXl*A5Zw!7VPILAOfu#ud&h7mxE!8yU4iHyTSjs');
define('NONCE_SALT',       'm#BJKf3Zv9Db25vet9eeBN67UmDgLiGp%7gtL!Sr5zeVp#!&yzn1h@YZA)nE!FP1');
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define( 'WP_ALLOW_MULTISITE', true );

define ('FS_METHOD', 'direct');
// remove x-pingback HTTP header
add_filter('wp_headers', function($headers) {
  unset($headers['X-pingback']);
  return $headers;
});
// disable pingbacks
  add_filter( 'xmlrpc_methods', function( $methods ) {
  unset( $methods['pingback.ping'] );
  return $methods;
});
